package ir.obd.app

// Candidate families only: actual fitment depends on production year and ECU label.
data class VehicleProfile(val name: String, val engines: List<String>, val families: List<String>)
val iranProfiles = listOf(
    VehicleProfile("پژو ۲۰۶ / ۲۰۷ / رانا", listOf("TU3", "TU5", "TU5P"), listOf("Bosch ME7.4.4", "Bosch ME7.4.5", "Valeo J34", "Continental / Siemens", "ایزی‌یو")),
    VehicleProfile("پژو ۴۰۵ / پارس / سمند", listOf("XU7", "XU7P", "TU5", "EF7"), listOf("Sagem SL96", "Sagem S2000", "Valeo S2000", "Siemens", "Bosch ME7.4.9", "Bosch ME17", "ایزی‌یو")),
    VehicleProfile("دنا / دنا پلاس / سورن", listOf("EF7", "EF7 Turbo", "EF7P", "XU7P"), listOf("Bosch ME17", "Siemens / Continental", "ایزی‌یو")),
    VehicleProfile("پراید", listOf("B3", "M13"), listOf("Sagem", "Siemens", "Valeo", "کروز")),
    VehicleProfile("تیبا / ساینا / کوییک", listOf("M15", "M15GSI"), listOf("Siemens / Continental", "کروز", "ایزی‌یو")),
    VehicleProfile("شاهین", listOf("M15 Turbo", "ME16"), listOf("کروز", "سایر")),
    VehicleProfile("تارا", listOf("TU5P"), listOf("Continental", "ایزی‌یو", "سایر")),
    VehicleProfile("تندر ۹۰ / ساندرو", listOf("K4M"), listOf("Siemens EMS3132", "Continental EMS", "سایر")),
    VehicleProfile("آریسان / وانت باردو", listOf("OHV", "XU7P"), listOf("Siemens", "ایزی‌یو", "سایر")),
    VehicleProfile("سایر خودروها", listOf("نامشخص"), listOf("نامشخص"))
)

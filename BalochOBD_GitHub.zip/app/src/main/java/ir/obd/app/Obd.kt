package ir.obd.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

data class Live(
    val rpm: Double? = null, val speed: Double? = null, val coolant: Double? = null,
    val iat: Double? = null, val map: Double? = null, val maf: Double? = null,
    val load: Double? = null, val throttle: Double? = null, val volt: Double? = null
)

class ObdClient {
    private var sock: BluetoothSocket? = null
    private var tcp: java.net.Socket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null
    private var isCan = false
    private val fails = HashMap<Int, Int>()

    @SuppressLint("MissingPermission")
    fun connect(dev: BluetoothDevice, proto: String) {
        close(); fails.clear()
        val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect(); sock = s; inp = s.inputStream; out = s.outputStream
        initialize(proto)
    }

    fun connectWifi(host: String, port: Int, proto: String) {
        close(); fails.clear()
        val s = java.net.Socket(); tcp = s
        s.connect(java.net.InetSocketAddress(host, port), 5000)
        inp = s.getInputStream(); out = s.getOutputStream()
        initialize(proto)
    }

    private fun initialize(proto: String) {
        send("ATZ")
        for (c in listOf("ATE0", "ATL0", "ATS1", "ATH0", "ATSP$proto")) send(c)
        val r = send("0100")
        if (r.contains("UNABLE") || r.contains("ERROR") || r.contains("NO DATA"))
            throw IOException("ECU جواب نداد (سوئیچ باز است؟ پروتکل را عوض کنید)")
        val p = send("ATDPN").filter { it.isLetterOrDigit() }.removePrefix("A")
        isCan = p.firstOrNull()?.let { it in '6'..'9' } ?: false
    }

    fun close() { try { sock?.close() } catch (_: Exception) {}; sock = null; try { tcp?.close() } catch (_: Exception) {}; tcp = null; out = null; inp = null }

    @Synchronized
    fun send(cmd: String): String {
        val o = out ?: throw IOException("اتصال قطع است"); val i = inp!!
        while (i.available() > 0) i.read()
        o.write((cmd + "\r").toByteArray()); o.flush()
        val sb = StringBuilder(); val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 8000) {
            if (i.available() > 0) { val c = i.read().toChar(); if (c == '>') break; sb.append(c) }
            else Thread.sleep(5)
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim()
    }

    private fun bytes(r: String) = r.split(' ')
        .filter { it.length == 2 && it.all { c -> c in '0'..'9' || c in 'A'..'F' } }.map { it.toInt(16) }

    private fun query(pid: Int): List<Int>? {
        if ((fails[pid] ?: 0) >= 3) return null
        val b = bytes(send("01%02X".format(pid)))
        val k = (0 until b.size - 1).firstOrNull { b[it] == 0x41 && b[it + 1] == pid }
        if (k == null) { fails[pid] = (fails[pid] ?: 0) + 1; return null }
        fails[pid] = 0
        return b.drop(k + 2)
    }

    private fun a(pid: Int) = query(pid)?.firstOrNull()?.toDouble()
    private fun w(pid: Int) = query(pid)?.takeIf { it.size >= 2 }?.let { it[0] * 256.0 + it[1] }

    fun readLive() = Live(
        rpm = w(0x0C)?.let { it / 4 }, speed = a(0x0D), coolant = a(0x05)?.let { it - 40 },
        iat = a(0x0F)?.let { it - 40 }, map = a(0x0B), maf = w(0x10)?.let { it / 100 },
        load = a(0x04)?.let { it * 100 / 255 }, throttle = a(0x11)?.let { it * 100 / 255 },
        volt = w(0x42)?.let { it / 1000 }
    )

    fun readDtc(mode: String = "03"): List<String> {
        val b = bytes(send(mode))
        val k = b.indexOf(0x40 + mode.toInt(16)); if (k < 0) return emptyList()
        var r = b.drop(k + 1); if (isCan) r = r.drop(1)
        return r.chunked(2).filter { it.size == 2 && (it[0] != 0 || it[1] != 0) }
            .map { "PCBU"[it[0] shr 6].toString() + ((it[0] shr 4) and 3) + "%X%02X".format(it[0] and 15, it[1]) }
            .distinct()
    }

    fun extraLive(): Map<String, Double> {
        val result = mutableMapOf<String, Double>()
        for ((pid, name) in listOf(6 to "STFT1", 7 to "LTFT1", 8 to "STFT2", 9 to "LTFT2")) a(pid)?.let { result[name] = (it-128)*100/128 }
        a(0x0E)?.let { result["timing"] = it/2-64 }
        a(0x2F)?.let { result["fuel level"] = it*100/255 }
        a(0x33)?.let { result["barometric"] = it }
        a(0x46)?.let { result["ambient"] = it-40 }
        a(0x14)?.let { result["O2 B1S1"] = it/200 }
        a(0x15)?.let { result["O2 B1S2"] = it/200 }
        return result
    }
    fun workshopScan(): String = buildString {
        fun read(label: String, cmd: String) {
            val response = send(cmd)
            appendLine("$label: ${response.ifBlank { "بدون پاسخ" }}")
        }
        read("شناسه دانگل", "ATI")
        read("پروتکل", "ATDP")
        read("ولتاژ ورودی دانگل", "ATRV")
        read("VIN (پاسخ خام)", "0902")
        read("شناسه کالیبراسیون (خام)", "0904")
        read("وضعیت مانیتورهای آلایندگی (خام)", "0101")
        read("پارامترهای پشتیبانی شده (خام)", "0100")
        read("Freeze frame دور موتور (خام)", "020C00")
        read("Freeze frame دمای موتور (خام)", "020500")
        read("Freeze frame سرعت (خام)", "020D00")
        read("خطاهای ثبت شده (خام)", "03")
        read("خطاهای در انتظار (خام)", "07")
        read("خطاهای دائمی (خام)", "0A")
        read("نتایج مانیتور داخلی (خام)", "06")
    }
    fun diagnosticReport(kind: Int): String = buildString {
        fun raw(label: String, cmd: String) {
            appendLine("$label: ${send(cmd).ifBlank { "بدون پاسخ" }}")
        }
        fun data(mode: Int, pid: Int, frame: Boolean = false): List<Int>? {
            val b = bytes(send("%02X%02X".format(mode, pid) + if (frame) "00" else ""))
            val k = (0 until b.size - 1).firstOrNull { b[it] == mode + 64 && b[it+1] == pid } ?: return null
            return b.drop(k + if (frame) 3 else 2)
        }
        fun measure(label: String, pid: Int, frame: Boolean = false, convert: (List<Int>) -> String?) {
            appendLine("$label: ${data(if (frame) 2 else 1, pid, frame)?.let(convert) ?: "پاسخ معتبر موجود نیست"}")
        }
        when (kind) {
            0 -> append(workshopScan())
            1 -> for ((mode, title) in listOf("03" to "ثبت شده", "07" to "در انتظار", "0A" to "دائمی")) {
                val codes = readDtc(mode)
                appendLine("خطاهای $title: ${if (codes.isEmpty()) "کدی استخراج نشد" else codes.joinToString()}")
                codes.forEach { appendLine("$it — ${dtcDesc(it)}") }
            }
            2 -> {
                raw("کد مرتبط با فریز فریم (خام)", "020200")
                measure("دور موتور RPM", 12, true) { if (it.size >= 2) ((it[0]*256+it[1])/4.0).toString() else null }
                measure("سرعت km/h", 13, true) { it.firstOrNull()?.toString() }
                measure("دمای آب °C", 5, true) { it.firstOrNull()?.minus(40)?.toString() }
                measure("بار موتور %", 4, true) { it.firstOrNull()?.let { a -> "%.1f".format(a*100.0/255) } }
                measure("فشار مانیفولد kPa", 11, true) { it.firstOrNull()?.toString() }
            }
            3 -> {
                val b = data(1,1)
                if (b != null && b.size >= 4) {
                    appendLine("چراغ چک: ${if (b[0] and 128 != 0) "روشن" else "خاموش"}")
                    appendLine("تعداد خطاهای اعلامی ECU: ${b[0] and 127}")
                    for ((i,n) in listOf("احتراق ناقص", "سیستم سوخت", "اجزای جامع").withIndex()) {
                        appendLine("$n: ${if (b[1] and (1 shl i) == 0) "پشتیبانی نشده" else if (b[1] and (16 shl i) != 0) "تکمیل نشده" else "تکمیل شده"}")
                    }
                } else appendLine("وضعیت معتبر دریافت نشد")
                raw("سایر مانیتورها (خام)", "0101")
                raw("نتایج آزمون داخلی (خام)", "06")
            }
            4 -> {
                raw("ولتاژ ورودی دانگل", "ATRV")
                measure("ولتاژ ECU V", 0x42) { if (it.size >= 2) "%.2f".format((it[0]*256+it[1])/1000.0) else null }
                appendLine("برای تشخیص باتری و دینام، اندازه گیری مستقل و آزمون تحت بار لازم است.")
            }
            5 -> {
                raw("شناسه دانگل", "ATI"); raw("پروتکل", "ATDP")
                raw("VIN (خام)", "0902"); raw("کالیبراسیون (خام)", "0904"); raw("CVN (خام)", "0906")
                for (pid in listOf("00", "20", "40", "60")) raw("نقشه پشتیبانی PID $pid", "01$pid")
            }
        }
    }
    fun clearDtc() = send("04")
}
